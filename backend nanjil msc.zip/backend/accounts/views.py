from django.shortcuts import render

# Create your views here.
import json

from django.contrib.auth import authenticate, get_user_model
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST

User = get_user_model()


@csrf_exempt  # For this small learning API; use proper CSRF protection in production.
@require_POST
def signup(request):
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({"error": "Invalid JSON."}, status=400)

    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    if not email or not password:
        return JsonResponse(
            {"error": "Email and password are required."},
            status=400,
        )

    if User.objects.filter(username=email).exists():
        return JsonResponse(
            {"error": "An account with that email already exists."},
            status=400,
        )

    # create_user hashes the password before saving it.
    user = User.objects.create_user(
        username=email,
        email=email,
        password=password,
    )

    return JsonResponse(
        {"message": "Account created.", "email": user.email},
        status=201,
    )


@csrf_exempt  # For this small learning API; use proper CSRF protection in production.
@require_POST
def login(request):
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({"error": "Invalid JSON."}, status=400)

    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    user = authenticate(request, username=email, password=password)

    if user is None:
        return JsonResponse(
            {"error": "Email or password is incorrect."},
            status=401,
        )

    return JsonResponse({"message": "Login successful.", "email": user.email})